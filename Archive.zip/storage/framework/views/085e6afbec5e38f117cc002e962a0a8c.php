<?php $__env->startSection('title', 'قرض ' . $loan->id); ?>
<?php $__env->startSection('content'); ?>
    <div class="page-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                        <h4 class="mb-sm-0 font-size-18">قرض <?php echo e($loan->id); ?></h4>

                        

                    </div>
                </div>
            </div>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <div class="row">
                <div class="col-xl-12">
                    <div class="card">
                        <h5 class="card-header bg-transparent border-bottom text-uppercase">معلومات القروض</h5>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-lg-4 col-12">
                                    <b>رقم القرض</b> : <?php echo e($loan->id); ?>

                                </div>
                                <div class="col-lg-4 col-12">
                                    <b>رقم الطلب</b> : <a href="/form-requests/<?php echo e($loan->request->form_request_id); ?>"
                                        target="_blank"><?php echo e($loan->request->form_request_id); ?> <i
                                            class="fa fa-external-link"></i></a>
                                </div>
                                <div class="col-lg-4 col-12">
                                    <b>حالة القرض</b> :
                                    <?php if($loan->status_id == 1): ?>
                                        <span class="badge rounded-pill bg-info"
                                            style="font-size: 12px; font-weight:600"><?php echo e($loan->status->status_desc); ?></span>
                                    <?php elseif($loan->status_id == 2): ?>
                                        <span class="badge rounded-pill bg-info" style="font-size: 12px; font-weight:600">
                                            <?php echo e($loan->status->status_desc); ?></span>
                                    <?php elseif($loan->status_id == 3): ?>
                                        <span class="badge rounded-pill bg-primary"
                                            style="font-size: 12px; font-weight:600">
                                            <?php echo e($loan->status->status_desc); ?></span>
                                    <?php elseif($loan->status_id == 4): ?>
                                        <span class="badge rounded-pill bg-primary"
                                            style="font-size: 12px; font-weight:600"><?php echo e($loan->status->status_desc); ?></span>
                                    <?php elseif($loan->status_id == 5): ?>
                                        <span class="badge rounded-pill bg-success"
                                            style="font-size: 12px; font-weight:600"><?php echo e($loan->status->status_desc); ?></span>
                                    <?php elseif($loan->status_id == 6): ?>
                                        <span class="badge rounded-pill bg-danger"
                                            style="font-size: 12px; font-weight:600"><?php echo e($loan->status->status_desc); ?></span>
                                    <?php elseif($loan->status_id == 7): ?>
                                        <?php echo e($loan->status->status_desc); ?>

                                    <?php endif; ?>
                                </div>

                                <div class="col-lg-4 col-12 mt-4">
                                    <b>مبلغ القرض</b> :<?php echo e($loan->loan_amount); ?>

                                </div>
                                <div class="col-lg-4 col-12 mt-4">
                                    <b>تاريخ التمويل</b> :<?php echo e(\Carbon\Carbon::parse($loan->released_date)->format('Y-m-d')); ?>

                                </div>
                                <div class="col-lg-4 col-12 mt-4">
                                    <b>فائدة القرض</b> :<?php echo e($loan->loan_interest); ?>

                                </div>
                                <div class="col-lg-4 col-12 mt-4">
                                    <b>الفائدة بال</b> :<?php echo e($loan->loan_interest_per); ?>

                                </div>
                                <div class="col-lg-4 col-12 mt-4">
                                    <b>مدة القرض</b> :<?php echo e($loan->loan_duration); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- end card -->
                </div>
                <!-- end col -->
                <div class="col-xl-12">
                    <div class="card">
                        <h5 class="card-header bg-transparent border-bottom text-uppercase">معلومات التمويل</h5>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-lg-4 col-12 mb-3">
                                    <b> منتج التمويل</b> : <?php echo e($loan->product->product_name); ?>

                                </div>
                                <div class="col-lg-4 col-12 mb-3">
                                    <b>مؤسسة التمويل</b> : <?php echo e($loan->mfi_provider->name_ar ?? '-'); ?>


                                </div>
                                <div class="col-lg-4 col-12 mb-3">
                                    <b>الوصف </b> : <?php echo e($loan->description); ?>

                                </div>

                            </div>
                        </div>
                    </div>
                    <!-- end card -->
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/ahmedmagdi/Desktop/work/tayseer/tayseer_customer/resources/views/Loans/show.blade.php ENDPATH**/ ?>