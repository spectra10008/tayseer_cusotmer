<?php $__env->startSection('title', 'انشاء طلب'); ?>
<?php $__env->startPush('pushcss'); ?>
<style>
    .asteresk{
        color:red;
        font-size: 15px;
    }
</style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <div class="page-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                                <h4 class="card-title">إنشاء بيانات الطلب</h4>
                        </div>
                        <div class="card-body p-4">
                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger mb-2">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>
                            <form action="/form-requests" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="latitude" id="latitude" readonly class="form-control"
                                    value="<?php echo e(old('latitude')); ?>">
                                <input type="hidden" name="longitude" id="longitude" readonly class="form-control"
                                    value="<?php echo e(old('longitude')); ?>">
                                <div class="row">
                                    <h5 class="font-size-14 mb-4"><i class="mdi mdi-arrow-right text-primary me-1"></i>
                                        معلومات المشروع والتمويل
                                    </h5>
                                    <div class="col-lg-6">
                                        <div>
                                            <div class="mb-3">
                                                <label for="example-text-input" class="form-label">إسم المشروع <span class="asteresk">*</span></label>
                                                <input type="text"
                                                class="form-control <?php $__errorArgs = ['project_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                name="project_name" placeholder="اسم المشروع"
                                                value="<?php echo e(old('project_name')); ?>" required>
                                            </div>
                                            <div class="mb-3">
                                                <label for="example-text-input" class="form-label">نوع التمويل<span class="asteresk">*</span></label>
                                                <select name="fund_type_id"
                                                        class="form-select <?php $__errorArgs = ['fund_type_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        required>
                                                        <option value="">إختار</option>
                                                        <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($type->id); ?>"<?php if($type->id == old('fund_type_id')): echo 'selected'; endif; ?>>
                                                                <?php echo e($type->type_name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                            </div>
                                            <div class="mb-3">
                                                <label for="example-email-input" class="form-label">معلومات المشروع <span class="asteresk">*</span></label>
                                                <textarea name="project_desc" class="ckeditor form-control <?php $__errorArgs = ['project_desc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required><?php echo e(old('project_desc')); ?></textarea>
                                            </div>

                                        </div>
                                    </div>

                                    <div class="col-lg-6">
                                        <div class="mt-3 mt-lg-0">
                                            <div class="mb-3">
                                                <label for="example-date-input" class="form-label">القطاع <span class="asteresk">*</span></label>
                                                <select name="project_sector_id"
                                                class="form-select <?php $__errorArgs = ['project_sector_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                required>
                                                <option value="">إختار</option>
                                                <?php $__currentLoopData = $sectors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sector): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($sector->id); ?>"<?php if($sector->id == old('project_sector_id')): echo 'selected'; endif; ?>>
                                                        <?php echo e($sector->sector_desc); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            </div>
                                            <div class="mb-3">
                                                <label for="example-search-input" class="form-label"> قيمة التمويل المطلوب بالجنيه <span class="asteresk">*</span></label>
                                                <input type="text"
                                                class="form-control <?php $__errorArgs = ['project_fund_need'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                name="project_fund_need"
                                                placeholder="قيمة التمويل المطلوب بالجنيه السوداني"
                                                value="<?php echo e(old('project_fund_need')); ?>" required>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <hr>
                                </div>
                                <div class="row mt-4">
                                    <h5 class="font-size-14 mb-4"><i class="mdi mdi-arrow-right text-primary me-1"></i>
                                        ملفات
                                    </h5>

                                    <div class="col-lg-6">
                                        <div>
                                            <div class="mb-3">
                                                <label for="first-name-vertical"> الصورة الشخصية<span class="asteresk">*</span></label>
                                                <input type="file"
                                                        class="form-control <?php $__errorArgs = ['personal_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        name="personal_image" required value="<?php echo e(old('personal_image')); ?>">
                                            </div>
                                            <div class="mb-3">
                                                <label for="first-name-vertical">دراسة الجدوى <span class="asteresk">*</span></label>
                                                <input type="file"
                                                class="form-control <?php $__errorArgs = ['feasibility_study_file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                name="feasibility_study_file"
                                                value="<?php echo e(old('feasibility_study_file')); ?>">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="mt-3 mt-lg-0">
                                            <div class="mb-3">
                                                <label for="first-name-vertical">صورة الهوية<span class="asteresk">*</span></label>
                                                <input type="file"
                                                        class="form-control <?php $__errorArgs = ['id_file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        name="id_file" value="<?php echo e(old('id_file')); ?>">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="mt-4">
                                    <button type="submit" class="btn btn-primary w-md">حفظ</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div> <!-- end col -->
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('pushjs'); ?>
    <script src="https://maps.google.com/maps/api/js?key=AIzaSyA-CFZMuoj6iTzpFJCGUrQUmrQuuw-ZZiE" type="text/javascript">
    </script>
    <script>
        function getUserLocation() {
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(function(position) {
                    var latitude = position.coords.latitude;
                    var longitude = position.coords.longitude;
                    var locationText = "Latitude: " + latitude + "<br>Longitude: " + longitude;
                    $('#latitude').val(latitude);
                    $('#longitude').val(longitude);
                    // document.getElementById("location").innerHTML = locationText;
                }, function() {
                    console.error("Error getting user's location.");
                    // document.getElementById("location").innerHTML = "Error getting user's location.";
                });
            } else {
                console.error("Geolocation is not supported by your browser.");
                // document.getElementById("location").innerHTML = "Geolocation is not supported by your browser.";
            }
        }

        // Call the getUserLocation function when the page loads
        window.onload = getUserLocation;
    </script>
    <?php $old_is_bank = old('is_bank_account'); ?>
    <script>
        $(document).ready(function() {
            if (<?php echo json_encode($old_is_bank, 15, 512) ?> == 1) {
                $('.bank_id').removeClass('d-none');
                $('.branch_name').removeClass('d-none');
                $('.account_no').removeClass('d-none');
            }
            $("select[name='is_bank_account']").change(function() {
                var select_id = this.value;
                if (select_id == 1) {
                    $('.bank_id').removeClass('d-none');
                    $('.branch_name').removeClass('d-none');
                    $('.account_no').removeClass('d-none');
                } else {
                    $('.bank_id').addClass('d-none');
                    $('.branch_name').addClass('d-none');
                    $('.account_no').addClass('d-none');
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/ahmedmagdi/Desktop/work/tayseer/tayseer_customer/resources/views/form_requests/create.blade.php ENDPATH**/ ?>