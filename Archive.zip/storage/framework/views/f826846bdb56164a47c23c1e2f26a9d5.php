<?php $__env->startSection('title', 'اكمال البيانات الشخصية'); ?>
<?php $__env->startPush('pushcss'); ?>
<style>
    .asteresk{
        color:red;
        font-size: 15px;
    }
</style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <div class="page-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                                <h4 class="card-title">تعديل بياناتك الشخصية</h4>
                        </div>
                        <div class="card-body p-4">
                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger mb-2">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>
                            <form action="/complete-profile" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PATCH'); ?>
                                <input type="hidden" name="latitude" id="latitude" readonly class="form-control"
                                    value="<?php echo e(old('latitude')); ?>">
                                <input type="hidden" name="longitude" id="longitude" readonly class="form-control"
                                    value="<?php echo e(old('longitude')); ?>">
                                <div class="row">
                                    <h5 class="font-size-14 mb-4"><i class="mdi mdi-arrow-right text-primary me-1"></i>
                                        المعلومات الشخصية
                                    </h5>

                                    <div class="col-lg-6">
                                        <div>
                                            <div class="mb-3">
                                                <label for="example-text-input" class="form-label">الاسم <span class="asteresk">*</span></label>
                                                <input type="text"
                                                    class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name"
                                                    placeholder="اسم مستفيد" value="<?php echo e(old('name',auth()->guard('beneficiaries')->user()->name)); ?>" required>
                                            </div>
                                            <div class="mb-3">
                                                <label for="example-date-input" class="form-label">البريد الالكتروني (اختياري)</label>
                                                <input type="email"
                                                    class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email"
                                                    placeholder="البريد الألكتروني" value="<?php echo e(old('email',auth()->guard('beneficiaries')->user()->email)); ?>">
                                            </div>
                                            <div class="mb-3">
                                                <label for="example-email-input" class="form-label">العمر <span class="asteresk">*</span></label>
                                                <input type="number"
                                                    class="form-control <?php $__errorArgs = ['age'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="age"
                                                    placeholder="العمر" value="<?php echo e(old('age',auth()->guard('beneficiaries')->user()->age)); ?>" required>
                                            </div>
                                            <div class="mb-3">
                                                <label for="example-url-input" class="form-label">الحالة الاجتماعية <span class="asteresk">*</span></label>
                                                <select name="social_situation_id"
                                                    class="form-select <?php $__errorArgs = ['social_situation_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    required>
                                                    <option value="">إختار</option>
                                                    <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($status->id); ?>"<?php if($status->id == old('social_situation_id',auth()->guard('beneficiaries')->user()->social_situation_id)): echo 'selected'; endif; ?>>
                                                            <?php echo e($status->situation_desc); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                            <div class="mb-3">
                                                <label for="example-tel-input" class="form-label">العنوان <span class="asteresk">*</span></label>
                                                <input type="text"
                                                    class="form-control <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    name="address" placeholder="العنوان" value="<?php echo e(old('address',auth()->guard('beneficiaries')->user()->address)); ?>"
                                                    required>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-lg-6">
                                        <div class="mt-3 mt-lg-0">
                                            <div class="mb-3">
                                                <label for="example-date-input" class="form-label">الجنس <span class="asteresk">*</span></label>
                                                <select name="gender"
                                                    class="form-select <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                    <option value="">إختار</option>
                                                    <option value="male"<?php if(old('gender',auth()->guard('beneficiaries')->user()->gender) == 'male'): echo 'selected'; endif; ?>>ذكر</option>
                                                    <option value="female"<?php if(old('gender',auth()->guard('beneficiaries')->user()->gender) == 'female'): echo 'selected'; endif; ?>>أنثى</option>
                                                </select>
                                            </div>
                                            <div class="mb-3">
                                                <label for="example-search-input" class="form-label">رقم الهاتف <span class="asteresk">*</span></label>
                                                <input type="number"
                                                    class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="phone"
                                                    placeholder="رقم الهاتف" value="<?php echo e(old('phone',auth()->guard('beneficiaries')->user()->phone)); ?>" required>
                                            </div>

                                            <div class="mb-3">
                                                <label for="example-week-input" class="form-label">الرقم الوطني <span class="asteresk">*</span></label>
                                                <input type="number"
                                                    class="form-control <?php $__errorArgs = ['id_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    name="id_number" placeholder="الرقم الوطني"
                                                    value="<?php echo e(old('id_number',auth()->guard('beneficiaries')->user()->id_number)); ?>" required>
                                            </div>
                                            <div class="mb-3">
                                                <label for="example-month-input" class="form-label">عدد الاولاد <span class="asteresk">*</span></label>
                                                <input type="number"
                                                    class="form-control <?php $__errorArgs = ['children_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    name="children_no" placeholder="عدد الأولاد"
                                                    value="<?php echo e(old('children_no',auth()->guard('beneficiaries')->user()->children_no)); ?>" required>
                                            </div>
                                            <div class="mb-3">
                                                <label for="example-month-input" class="form-label">كلمة السر<span class="asteresk">*</span></label>
                                                <input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mt-4">
                                    <h5 class="font-size-14 mb-4"><i class="mdi mdi-arrow-right text-primary me-1"></i>
                                        المعلومات البنكية
                                    </h5>

                                    <div class="col-lg-6">
                                        <div>
                                            <div class="mb-3">
                                                <label for="first-name-vertical">حساب بنكي ؟ <span class="asteresk">*</span></label>
                                                <select name="is_bank_account"
                                                    class="form-select <?php $__errorArgs = ['is_bank_account'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    required>
                                                    <option value="">إختار</option>
                                                    <option value="0" <?php if(old('is_bank_account',auth()->guard('beneficiaries')->user()->is_bank_account) == 0): echo 'selected'; endif; ?>>لا</option>
                                                    <option value="1" <?php if(old('is_bank_account',auth()->guard('beneficiaries')->user()->is_bank_account) == 1): echo 'selected'; endif; ?>>نعم</option>
                                                </select>
                                            </div>
                                            <div class="mb-3 branch_name <?php if(auth()->guard('beneficiaries')->user()->is_bank_account == 0): ?> d-none <?php endif; ?>">
                                                <label for="first-name-vertical">اسم الفرع <span class="asteresk">*</span></label>
                                                <input type="text"
                                                    class="form-control <?php $__errorArgs = ['branch_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    name="branch_name" placeholder="اسم الفرع"
                                                    value="<?php echo e(old('branch_name',auth()->guard('beneficiaries')->user()->branch_name)); ?>">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="mt-3 mt-lg-0">
                                            <div class="mb-3 bank_id <?php if(auth()->guard('beneficiaries')->user()->is_bank_account == 0): ?> d-none <?php endif; ?>">
                                                <label for="first-name-vertical">اسم البنك <span class="asteresk">*</span></label>
                                                <select name="bank_id"
                                                    class="form-select <?php $__errorArgs = ['bank_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                    <option value="">إختار</option>
                                                    <?php $__currentLoopData = $banks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($bank->id); ?>" <?php if(old('bank_id',auth()->guard('beneficiaries')->user()->bank_id) == $bank->id): echo 'selected'; endif; ?>>
                                                            <?php echo e($bank->bank_name); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                            <div class="mb-3 account_no <?php if(auth()->guard('beneficiaries')->user()->is_bank_account == 0): ?> d-none <?php endif; ?>">
                                                <label for="first-name-vertical">رقم الحساب <span class="asteresk">*</span></label>
                                                <input type="number"
                                                    class="form-control <?php $__errorArgs = ['account_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    name="account_no" placeholder="رقم الحساب"
                                                    value="<?php echo e(old('account_no',auth()->guard('beneficiaries')->user()->account_no)); ?>">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mt-4">
                                    <h5 class="font-size-14 mb-4"><i class="mdi mdi-arrow-right text-primary me-1"></i>
                                        الملفات
                                    </h5>

                                    <div class="col-lg-6">
                                        <div>
                                            <div class="mb-3">
                                                <label for="first-name-vertical">الصورة الشخصية <span class="asteresk">*</span></label>
                                                <input type="file"
                                                        class="form-control <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        name="image" <?php if(auth()->guard('beneficiaries')->user()->image == null): ?> required <?php endif; ?>>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="mt-3 mt-lg-0">
                                            <div class="mb-3">
                                                <label for="first-name-vertical">صورة الهوية <span class="asteresk">*</span></label>
                                                <input type="file"
                                                class="form-control <?php $__errorArgs = ['id_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                name="id_image"  <?php if(auth()->guard('beneficiaries')->user()->id_image == null): ?> required <?php endif; ?>>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="mt-4">
                                    <button type="submit" class="btn btn-primary w-md">حفظ</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div> <!-- end col -->
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('pushjs'); ?>
    <script src="https://maps.google.com/maps/api/js?key=AIzaSyA-CFZMuoj6iTzpFJCGUrQUmrQuuw-ZZiE" type="text/javascript">
    </script>
    <script>
        function getUserLocation() {
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(function(position) {
                    var latitude = position.coords.latitude;
                    var longitude = position.coords.longitude;
                    var locationText = "Latitude: " + latitude + "<br>Longitude: " + longitude;
                    $('#latitude').val(latitude);
                    $('#longitude').val(longitude);
                    // document.getElementById("location").innerHTML = locationText;
                }, function() {
                    console.error("Error getting user's location.");
                    // document.getElementById("location").innerHTML = "Error getting user's location.";
                });
            } else {
                console.error("Geolocation is not supported by your browser.");
                // document.getElementById("location").innerHTML = "Geolocation is not supported by your browser.";
            }
        }

        // Call the getUserLocation function when the page loads
        window.onload = getUserLocation;
    </script>
    <?php $old_is_bank = old('is_bank_account'); ?>
    <script>
        $(document).ready(function() {
            if (<?php echo json_encode($old_is_bank, 15, 512) ?> == 1) {
                $('.bank_id').removeClass('d-none');
                $('.branch_name').removeClass('d-none');
                $('.account_no').removeClass('d-none');
            }
            $("select[name='is_bank_account']").change(function() {
                var select_id = this.value;
                if (select_id == 1) {
                    $('.bank_id').removeClass('d-none');
                    $('.branch_name').removeClass('d-none');
                    $('.account_no').removeClass('d-none');
                } else {
                    $('.bank_id').addClass('d-none');
                    $('.branch_name').addClass('d-none');
                    $('.account_no').addClass('d-none');
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/ahmedmagdi/Desktop/work/tayseer/tayseer_customer/resources/views/profile/edit.blade.php ENDPATH**/ ?>